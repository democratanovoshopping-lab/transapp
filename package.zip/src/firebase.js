import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Substitua com suas credenciais do Firebase!
const firebaseConfig = {
  apiKey: "AIzaSyBOv0YrWPlpkQ6OMN5vskj8LbnwzU2gKGI",
  authDomain: "transferencia-2baf1.firebaseapp.com",
  projectId: "transferencia-2baf1",
  storageBucket: "transferencia-2baf1.firebasestorage.app",
  messagingSenderId: "1017612179641",
  appId: "1:1017612179641:web:6e11a1bd0c7166f2e32368"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };